# module1_source.py

print('Running module1_source.py on saturday')

def hello():
    print('module1 says hello')