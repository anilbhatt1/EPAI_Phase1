# module1.py

print(f'loading module1.py: __name__ = {__name__}')