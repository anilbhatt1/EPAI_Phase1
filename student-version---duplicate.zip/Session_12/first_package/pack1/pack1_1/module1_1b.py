print('Executing module1_1b')
values = 'module1_1b values'