# numeric.py

__all__ = ['is_numeric', 'is_integer']

def is_numeric(arg):
    pass
def is_integer(arg):
    pass 
    
def numeric_helper_1():
    print('yeah you have access to me')
    pass

def numeric_helper_2():
    pass
