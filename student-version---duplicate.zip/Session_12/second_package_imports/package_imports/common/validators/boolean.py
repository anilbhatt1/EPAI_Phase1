# boolean.py

__all__ = ['is_boolean', 'boolean_helper_1']

def is_boolean(arg):
    pass

def boolean_helper_1():
    pass

def boolean_helper_2():
    pass