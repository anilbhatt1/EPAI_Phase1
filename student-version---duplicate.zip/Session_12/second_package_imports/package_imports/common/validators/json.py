# json.py

__all__ = ['is_json', 'constant']

def is_json(arg):
    pass

def json_helper_1():
    pass

def json_helper_2():
    pass

def constant():
    pass